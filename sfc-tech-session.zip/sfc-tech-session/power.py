'''
USING FOR LOOP
Accept a number and its power from the user. Calculate the result and print the output
Given x and y. Output will be x raised to y (x^y)
'''

x = int(input("Enter a number: "))
y = int(input("Enter the power: "))
ans = 1
######## Insert the for loop here ########

##########################################

print(str(x) + " raised to " + str(y) + " is = " + str(ans))
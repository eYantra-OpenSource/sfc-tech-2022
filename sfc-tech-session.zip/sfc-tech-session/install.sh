#!/bin/bash

# print a line 
echo "Hello User"

# install all the packages that are entered as argument
pkg install -y $*

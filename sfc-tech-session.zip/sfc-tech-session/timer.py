# Accept time (in seconds) from the user and set a countdown timer for the user.

import time

num = int(input("Enter the time in seconds: "))

######## Insert the for loop here ########

##########################################

print("TIMER OVER")
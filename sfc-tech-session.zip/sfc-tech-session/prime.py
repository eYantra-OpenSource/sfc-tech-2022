'''
USING FOR LOOP
Check if the user entered number is a prime number or not.
'''

num = int(input("Enter a number: "))
counter = 0

######## Insert the for loop here ########

##########################################
   
# Check counter only after the loop is finished. 
# Write the condition below to check if the number is prime or not:
if True:
    print("{} is a PRIME number".format(num))
else:
    print("{} is NOT a prime number".format(num))
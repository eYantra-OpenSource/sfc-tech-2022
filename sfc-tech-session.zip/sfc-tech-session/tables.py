'''
Accept a number, x, and print its multiplication table from x*1 to x*10.
2 x 1 = 2
2 x 2 = 4
2 x 3 = 6
2 x 4 = 8
2 x 5 = 10
.
.
2 x 10 = 20
'''

num = int(input("Enter the number: "))

i = 1
while i <= 10:
    # Complete the while loop